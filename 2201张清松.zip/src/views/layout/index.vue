<script>

import navbar from '@/views/navbar'

export default {
  components: {navbar}
}
</script>

<template>
  <div>
    <navbar/>
    <router-view/>
  </div>
</template>

<style scoped>

</style>